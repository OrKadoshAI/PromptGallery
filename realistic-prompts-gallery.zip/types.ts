export interface PromptItem {
  id: number;
  title: string;
  promptText: string;
  imageUrl: string;
  category: string;
}